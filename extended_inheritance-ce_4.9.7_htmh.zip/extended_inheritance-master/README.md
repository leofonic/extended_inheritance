------------------------------------------
OXID-MODUL "EXTENDED INHERITANCE"
------------------------------------------


Mit dem Modul k�nnen zus�tzliche Felder angegeben werden, die Varianten von den Vaterartikeln erben sollen. 
Das Modul ist vorkonfiguriert f�r die Vererbung des Gewichts und der Lieferzeit an die Varianten, kann aber auch f�r andere
Felder verwendet werden.
