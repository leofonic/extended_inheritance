<?php

$sLangName  = "Deutsch";
$aLang = array(
'charset'                                       => 'UTF-8',
'SHOP_MODULE_GROUP_main'                         => 'Einstellungen',
'SHOP_MODULE_aInheritFields'                         => 'Felder die Varianten immer vom Artikelvater erben sollen.<br>Jedes Feld in eine Zeile schreiben, ohne Komma am Ende!<br>Beispiele: oxarticles__oxtitle, etc.',
'SHOP_MODULE_aDoubleCopyFields'                      => 'Numerische Felder die Varianten vom Artikelvater erben sollen wenn der Wert bei der Variante 0 ist.<br>Jedes Feld in eine Zeile schreiben, ohne Komma am Ende!<br>Beispiele: oxarticles__oxpricea, oxarticles__oxweight, etc.',
);

